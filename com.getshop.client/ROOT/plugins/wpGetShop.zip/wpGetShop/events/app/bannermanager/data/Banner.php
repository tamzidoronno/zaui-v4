<?php
class app_bannermanager_data_Banner {
	/** @var String */
	public $imageId;

	/** @var String */
	public $productId;

}
?>