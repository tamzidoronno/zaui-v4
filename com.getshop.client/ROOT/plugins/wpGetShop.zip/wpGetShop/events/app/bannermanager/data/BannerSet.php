<?php
class app_bannermanager_data_BannerSet extends core_common_DataCommon  {
	/** @var String */
	public $banners;

	/** @var String */
	public $width;

	/** @var String */
	public $height;

	/** @var String */
	public $interval;

	/** @var String */
	public $listId;

}
?>