<?php
class app_footermanager_data_Configuration extends core_common_DataCommon  {
	/** @var String */
	public $columnType;

	/** @var String */
	public $columnIds;

	/** @var String */
	public $numberOfColumns;

}
?>