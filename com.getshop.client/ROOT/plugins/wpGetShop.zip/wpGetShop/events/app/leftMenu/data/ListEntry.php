<?php
class app_leftMenu_data_ListEntry extends core_common_DataCommon  {
	/** @var String */
	public $navigateByPages;

	/** @var String */
	public $name;

	/** @var String */
	public $parentId;

	/** @var String */
	public $subentries;

	/** @var String */
	public $orderId;

	/** @var String */
	public $products;

	/** @var String */
	public $pageId;

	/** @var String */
	public $imageId;

	/** @var String */
	public $hardLink;

	/** @var String */
	public $userLevel;

}
?>