<?php
class app_newsmanager_data_MailSubscription extends core_common_DataCommon  {
	/** @var String */
	public $email;

}
?>