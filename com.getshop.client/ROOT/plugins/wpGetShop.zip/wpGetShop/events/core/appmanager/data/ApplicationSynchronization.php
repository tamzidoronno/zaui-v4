<?php
class core_appmanager_data_ApplicationSynchronization extends core_common_DataCommon  {
	/** @var String */
	public $userId;

	/** @var String */
	public $appId;

	/** @var String */
	public $filename;

}
?>