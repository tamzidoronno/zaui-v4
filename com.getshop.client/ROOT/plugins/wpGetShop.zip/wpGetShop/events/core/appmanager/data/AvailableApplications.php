<?php
class core_appmanager_data_AvailableApplications extends core_common_DataCommon  {
	/** @var String */
	public $addedApplications;

	/** @var String */
	public $applications;

}
?>