<?php
class core_calendarmanager_data_ExtraDay {
	/** @var String */
	public $day;

	/** @var String */
	public $month;

	/** @var String */
	public $year;

	/** @var String */
	public $starttime;

	/** @var String */
	public $stoptime;

}
?>