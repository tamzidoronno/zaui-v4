<?php
class core_calendarmanager_data_Month extends core_common_DataCommon  {
	/** @var String */
	public $days;

	/** @var String */
	public $year;

	/** @var String */
	public $month;

}
?>