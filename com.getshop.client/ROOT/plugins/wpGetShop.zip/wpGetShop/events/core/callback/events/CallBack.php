<?php
class core_callback_events_CallBack extends core_common_MessageBase  {
	/** @var String */
	public $storeId;

	/** @var String */
	public $orderId;

	/** @var String */
	public $request;

	/** @var String */
	public $valuesString;

}
?>