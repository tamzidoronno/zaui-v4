<?php
class core_cartmanager_answer_GotCart extends core_common_AnswerMessage  {
	/** @var core_cartmanager_data_Cart */
	public $cart;

}
?>