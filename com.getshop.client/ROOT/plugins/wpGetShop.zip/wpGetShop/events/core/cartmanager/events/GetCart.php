<?php
class core_cartmanager_events_GetCart extends core_common_MessageBase  {
}
?>