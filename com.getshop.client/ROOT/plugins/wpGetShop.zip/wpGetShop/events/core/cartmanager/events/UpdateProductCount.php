<?php
class core_cartmanager_events_UpdateProductCount extends core_common_MessageBase  {
	/** @var String */
	public $productId;

	/** @var String */
	public $count;

}
?>