<?php
class core_chatmanager_ChatMessage {
	/** @var String */
	public $operator;

	/** @var String */
	public $message;

	/** @var String */
	public $rowCreatedDate;

}
?>