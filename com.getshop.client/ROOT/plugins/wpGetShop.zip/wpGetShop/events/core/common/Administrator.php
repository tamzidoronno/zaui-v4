<?php
class core_common_Administrator {
}
?>