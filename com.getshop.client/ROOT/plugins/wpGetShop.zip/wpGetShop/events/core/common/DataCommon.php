<?php
class core_common_DataCommon {
	/** @var String */
	public $id;

	/** @var String */
	public $storeId;

	/** @var String */
	public $deleted;

	/** @var String */
	public $className;

	/** @var String */
	public $rowCreatedDate;

}
?>