<?php
class core_common_ErrorMessage {
	/** @var String */
	public $additionalInformation;

	/** @var String */
	public $errorCode;

}
?>