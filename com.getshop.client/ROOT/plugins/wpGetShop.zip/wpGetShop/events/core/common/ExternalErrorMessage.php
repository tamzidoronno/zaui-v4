<?php
class core_common_ExternalErrorMessage {
	/** @var String */
	public $errorCode;

}
?>