<?php
class core_common_MessageBase {
	/** @var String */
	public $sessionId;

	/** @var String */
	public $guid;

	/** @var core_common_AppConfiguration */
	public $conf;

	/** @var String */
	public $sentFrom;

}
?>