<?php
class core_common_Setting extends core_common_DataCommon  {
	/** @var String */
	public $type;

	/** @var String */
	public $value;

	/** @var String */
	public $secure;

}
?>