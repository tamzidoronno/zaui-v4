<?php
class core_common_answer_ErrorMessage extends core_common_AnswerMessage  {
	/** @var String */
	public $additionalInformation;

	/** @var String */
	public $errorCode;

}
?>