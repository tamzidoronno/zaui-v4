<?php
class core_common_answer_Initialized extends core_common_AnswerMessage  {
	/** @var String */
	public $isSelenium;

	/** @var core_storemanager_data_Store */
	public $store;

	/** @var String */
	public $sessionId;

}
?>