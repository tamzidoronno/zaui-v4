<?php
class core_databasemanager_answer_UpdateAutoIncrementKeys extends core_common_AnswerMessage  {
	/** @var String */
	public $manager;

	/** @var String */
	public $key;

}
?>