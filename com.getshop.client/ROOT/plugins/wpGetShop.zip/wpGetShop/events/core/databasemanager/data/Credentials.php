<?php
class core_databasemanager_data_Credentials {
	/** @var String */
	public $managerClass;

	/** @var String */
	public $manangerName;

	/** @var String */
	public $password;

	/** @var String */
	public $storeid;

}
?>