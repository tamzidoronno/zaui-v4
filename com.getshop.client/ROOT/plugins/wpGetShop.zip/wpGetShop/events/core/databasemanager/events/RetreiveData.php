<?php
class core_databasemanager_events_RetreiveData extends core_common_MessageBase  {
	/** @var core_databasemanager_data_Credentials */
	public $credentials;

}
?>