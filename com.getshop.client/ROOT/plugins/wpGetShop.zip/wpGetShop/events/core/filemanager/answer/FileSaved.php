<?php
class core_filemanager_answer_FileSaved extends core_common_AnswerMessage  {
	/** @var String */
	public $fileId;

}
?>