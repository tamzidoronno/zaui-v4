<?php
class core_filemanager_answer_ImageDeleted extends core_common_AnswerMessage  {
	/** @var String */
	public $imageId;

}
?>