<?php
class core_filemanager_answer_ImageFromServer extends core_common_AnswerMessage  {
	/** @var core_filemanager_data_Image */
	public $image;

}
?>