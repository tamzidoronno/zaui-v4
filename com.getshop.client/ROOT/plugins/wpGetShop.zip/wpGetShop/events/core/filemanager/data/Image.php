<?php
class core_filemanager_data_Image extends core_common_DataCommon  {
	/** @var String */
	public $fitSize;

	/** @var String */
	public $imageData;

	/** @var String */
	public $height;

	/** @var String */
	public $width;

	/** @var String */
	public $originalWidth;

	/** @var String */
	public $originalHeight;

}
?>