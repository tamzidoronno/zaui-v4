<?php
class core_filemanager_events_DeleteImage extends core_common_MessageBase  {
	/** @var String */
	public $imageId;

}
?>