<?php
class core_filemanager_events_GetImage extends core_common_MessageBase  {
	/** @var String */
	public $height;

	/** @var String */
	public $width;

	/** @var String */
	public $imageId;

}
?>