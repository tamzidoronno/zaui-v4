<?php
class core_filemanager_events_GetImages extends core_common_MessageBase  {
	/** @var String */
	public $images;

}
?>