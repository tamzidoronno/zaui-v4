<?php
class core_filemanager_events_SaveFile extends core_common_MessageBase  {
	/** @var String */
	public $base64Encoded;

	/** @var String */
	public $image;

}
?>