<?php
class core_listmanager_answers_Entries extends core_common_AnswerMessage  {
	/** @var String */
	public $entries;

}
?>