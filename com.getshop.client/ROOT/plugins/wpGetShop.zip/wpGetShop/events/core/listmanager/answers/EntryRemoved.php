<?php
class core_listmanager_answers_EntryRemoved extends core_common_AnswerMessage  {
	/** @var String */
	public $id;

}
?>