<?php
class core_listmanager_answers_EntryUpdated extends core_common_AnswerMessage  {
	/** @var core_listmanager_data_Entry */
	public $entry;

}
?>