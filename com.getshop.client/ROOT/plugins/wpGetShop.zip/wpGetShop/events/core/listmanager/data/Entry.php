<?php
class core_listmanager_data_Entry {
	/** @var String */
	public $navigateByPages;

	/** @var String */
	public $name;

	/** @var String */
	public $parentId;

	/** @var String */
	public $pageId;

	/** @var String */
	public $imageId;

	/** @var String */
	public $hardLink;

	/** @var String */
	public $userLevel;

	/** @var String */
	public $id;

	/** @var String */
	public $productId;

	/** @var String */
	public $subentries;

}
?>