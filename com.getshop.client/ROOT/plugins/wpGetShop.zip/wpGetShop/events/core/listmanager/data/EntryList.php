<?php
class core_listmanager_data_EntryList extends core_common_DataCommon  {
	/** @var String */
	public $entries;

	/** @var String */
	public $appId;

	/** @var String */
	public $extendedLists;

}
?>