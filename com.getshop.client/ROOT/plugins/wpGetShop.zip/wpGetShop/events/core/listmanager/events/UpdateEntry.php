<?php
class core_listmanager_events_UpdateEntry extends core_common_MessageBase  {
	/** @var core_listmanager_data_Entry */
	public $entry;

}
?>