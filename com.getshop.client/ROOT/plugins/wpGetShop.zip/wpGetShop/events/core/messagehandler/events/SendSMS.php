<?php
class core_messagehandler_events_SendSMS extends core_common_MessageBase  {
	/** @var String */
	public $phoneNumber;

	/** @var String */
	public $message;

	/** @var String */
	public $from;

}
?>