<?php
class core_ordermanager_answer_OrderCreated extends core_common_AnswerMessage  {
	/** @var core_ordermanager_data_Order */
	public $order;

}
?>