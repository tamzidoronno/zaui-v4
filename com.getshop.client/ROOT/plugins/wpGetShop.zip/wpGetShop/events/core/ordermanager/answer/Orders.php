<?php
class core_ordermanager_answer_Orders extends core_common_AnswerMessage  {
	/** @var String */
	public $orders;

	/** @var String */
	public $totalCount;

}
?>