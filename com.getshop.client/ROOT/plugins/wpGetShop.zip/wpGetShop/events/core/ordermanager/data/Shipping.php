<?php
class core_ordermanager_data_Shipping {
	/** @var String */
	public $type;

	/** @var String */
	public $cost;

}
?>