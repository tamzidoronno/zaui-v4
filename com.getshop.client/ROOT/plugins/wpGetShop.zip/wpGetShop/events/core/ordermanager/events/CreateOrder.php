<?php
class core_ordermanager_events_CreateOrder extends core_common_MessageBase  {
	/** @var core_cartmanager_data_Cart */
	public $cart;

}
?>