<?php
class core_pagemanager_answer_ApplicationAdded extends core_common_AnswerMessage  {
	/** @var core_common_AppConfiguration */
	public $appConfiguration;

	/** @var core_pagemanager_data_Page */
	public $page;

}
?>