<?php
class core_pagemanager_answer_ApplicationRemoved extends core_common_AnswerMessage  {
	/** @var core_pagemanager_data_Page */
	public $page;

}
?>