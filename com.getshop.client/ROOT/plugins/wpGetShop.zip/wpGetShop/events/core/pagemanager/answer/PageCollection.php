<?php
class core_pagemanager_answer_PageCollection extends core_common_AnswerMessage  {
	/** @var String */
	public $applications;

	/** @var String */
	public $pageCollection;

}
?>