<?php
class core_pagemanager_answer_PageFound extends core_common_AnswerMessage  {
	/** @var String */
	public $applications;

	/** @var core_pagemanager_data_Page */
	public $page;

}
?>