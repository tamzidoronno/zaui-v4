<?php
class core_pagemanager_data_PageArea {
	/** @var String */
	public $applications;

	/** @var String */
	public $applicationsSequenceList;

	/** @var String */
	public $extraApplicationList;

	/** @var String */
	public $applicationsList;

	/** @var String */
	public $type;

	/** @var String */
	public $pageId;

}
?>