<?php
class core_pagemanager_data_ValueComparator {
	/** @var String */
	public $base;

}
?>