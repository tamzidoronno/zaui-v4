<?php
class core_pagemanager_events_AddApplication extends core_common_MessageBase  {
	/** @var String */
	public $applicationName;

}
?>