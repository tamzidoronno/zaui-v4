<?php
class core_pagemanager_events_AddApplicationToPageArea extends core_common_MessageBase  {
	/** @var core_pagemanager_data_PageArea */
	public $pageArea;

	/** @var String */
	public $applicationName;

	/** @var String */
	public $inheritate;

}
?>