<?php
class core_pagemanager_events_AddExtraEntry extends core_common_MessageBase  {
	/** @var String */
	public $year;

	/** @var String */
	public $month;

	/** @var String */
	public $day;

	/** @var String */
	public $eventId;

}
?>