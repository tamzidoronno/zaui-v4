<?php
class core_pagemanager_events_ChangePageLayout extends core_common_MessageBase  {
	/** @var String */
	public $pageId;

	/** @var String */
	public $skeletonType;

}
?>