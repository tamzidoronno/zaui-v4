<?php
class core_pagemanager_events_GetApplication extends core_common_MessageBase  {
	/** @var String */
	public $applicationName;

	/** @var String */
	public $applicationId;

}
?>