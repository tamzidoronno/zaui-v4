<?php
class core_pagemanager_events_GetPage extends core_common_MessageBase  {
	/** @var String */
	public $pageId;

}
?>