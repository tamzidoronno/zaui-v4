<?php
class core_pagemanager_events_GetPageCollection extends core_common_MessageBase  {
}
?>