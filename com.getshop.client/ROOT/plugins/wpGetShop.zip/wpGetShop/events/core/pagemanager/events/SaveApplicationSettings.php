<?php
class core_pagemanager_events_SaveApplicationSettings extends core_common_MessageBase  {
	/** @var String */
	public $settings;

	/** @var String */
	public $applicationId;

}
?>