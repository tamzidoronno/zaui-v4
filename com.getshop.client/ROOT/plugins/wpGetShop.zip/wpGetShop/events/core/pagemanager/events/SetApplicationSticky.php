<?php
class core_pagemanager_events_SetApplicationSticky extends core_common_MessageBase  {
	/** @var String */
	public $sticky;

}
?>