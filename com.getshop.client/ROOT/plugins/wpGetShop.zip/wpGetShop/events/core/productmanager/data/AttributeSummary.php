<?php
class core_productmanager_data_AttributeSummary {
	/** @var String */
	public $attributeCount;

}
?>