<?php
class core_productmanager_data_AttributeSummaryEntry {
	/** @var String */
	public $groupName;

	/** @var String */
	public $attributeCount;

	/** @var String */
	public $totalCount;

}
?>