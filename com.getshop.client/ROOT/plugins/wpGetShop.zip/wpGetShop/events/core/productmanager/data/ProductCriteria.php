<?php
class core_productmanager_data_ProductCriteria extends core_common_DataCommon  {
	/** @var String */
	public $parentPageIds;

	/** @var String */
	public $pageIds;

	/** @var String */
	public $ids;

	/** @var String */
	public $attributeFilter;

	/** @var String */
	public $listId;

	/** @var String */
	public $search;

}
?>