<?php
class core_productmanager_events_RemoveProduct extends core_common_MessageBase  {
	/** @var String */
	public $productId;

}
?>