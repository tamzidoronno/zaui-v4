<?php
class core_reportingmanager_data_OrderCreated {
	/** @var String */
	public $createdWhen;

	/** @var core_cartmanager_data_Cart */
	public $cart;

}
?>