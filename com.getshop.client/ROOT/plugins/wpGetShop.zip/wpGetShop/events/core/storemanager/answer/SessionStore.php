<?php
class core_storemanager_answer_SessionStore extends core_common_AnswerMessage  {
	/** @var core_storemanager_data_Store */
	public $store;

}
?>