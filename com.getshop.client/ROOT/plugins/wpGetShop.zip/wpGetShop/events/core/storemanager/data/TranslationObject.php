<?php
class core_storemanager_data_TranslationObject {
	/** @var String */
	public $key;

	/** @var String */
	public $value;

}
?>