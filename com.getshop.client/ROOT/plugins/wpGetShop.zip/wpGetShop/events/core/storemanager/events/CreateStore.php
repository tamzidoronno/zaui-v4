<?php
class core_storemanager_events_CreateStore extends core_common_MessageBase  {
	/** @var String */
	public $shopName;

	/** @var String */
	public $email;

	/** @var String */
	public $password;

}
?>