<?php
class core_storemanager_events_UpdateStoreConfiguration extends core_common_MessageBase  {
	/** @var core_storemanager_data_StoreConfiguration */
	public $configuration;

}
?>