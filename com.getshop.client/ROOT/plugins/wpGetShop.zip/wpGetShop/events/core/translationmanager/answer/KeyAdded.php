<?php
class core_translationmanager_answer_KeyAdded extends core_common_AnswerMessage  {
	/** @var String */
	public $key;

}
?>