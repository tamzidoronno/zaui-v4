<?php
class core_translationmanager_answer_TranslationAdded extends core_common_AnswerMessage  {
	/** @var String */
	public $app;

	/** @var String */
	public $languageCode;

	/** @var String */
	public $key;

}
?>