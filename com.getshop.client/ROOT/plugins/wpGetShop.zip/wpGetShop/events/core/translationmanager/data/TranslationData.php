<?php
class core_translationmanager_data_TranslationData extends core_common_DataCommon  {
	/** @var String */
	public $languageCode;

	/** @var String */
	public $isWebShop;

	/** @var String */
	public $translation;

}
?>