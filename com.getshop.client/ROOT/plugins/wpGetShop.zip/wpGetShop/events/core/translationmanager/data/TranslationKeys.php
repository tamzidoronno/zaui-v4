<?php
class core_translationmanager_data_TranslationKeys extends core_common_DataCommon  {
	/** @var String */
	public $keys;

}
?>