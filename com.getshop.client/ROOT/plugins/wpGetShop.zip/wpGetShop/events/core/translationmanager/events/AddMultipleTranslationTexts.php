<?php
class core_translationmanager_events_AddMultipleTranslationTexts extends core_common_MessageBase  {
	/** @var String */
	public $texts;

}
?>