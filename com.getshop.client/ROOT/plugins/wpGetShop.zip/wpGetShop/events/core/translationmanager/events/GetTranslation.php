<?php
class core_translationmanager_events_GetTranslation extends core_common_MessageBase  {
	/** @var String */
	public $languageCode;

}
?>