<?php
class core_translationmanager_events_UpdateTranslationKey extends core_common_MessageBase  {
	/** @var String */
	public $app;

	/** @var String */
	public $key;

	/** @var String */
	public $isFramework;

}
?>