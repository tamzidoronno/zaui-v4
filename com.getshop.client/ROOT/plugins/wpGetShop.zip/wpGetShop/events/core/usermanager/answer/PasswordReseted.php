<?php
class core_usermanager_answer_PasswordReseted extends core_common_AnswerMessage  {
}
?>