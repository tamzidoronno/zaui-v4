<?php
class core_usermanager_answer_ResetCodeSent extends core_common_AnswerMessage  {
}
?>