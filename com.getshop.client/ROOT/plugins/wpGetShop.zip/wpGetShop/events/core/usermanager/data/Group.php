<?php
class core_usermanager_data_Group extends core_common_DataCommon  {
	/** @var String */
	public $groupName;

	/** @var String */
	public $imageId;

}
?>