<?php
class core_usermanager_data_UserMockup {
}
?>