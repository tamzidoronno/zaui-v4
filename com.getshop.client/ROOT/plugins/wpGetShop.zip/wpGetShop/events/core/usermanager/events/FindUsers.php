<?php
class core_usermanager_events_FindUsers extends core_common_MessageBase  {
	/** @var String */
	public $searchCriteria;

}
?>