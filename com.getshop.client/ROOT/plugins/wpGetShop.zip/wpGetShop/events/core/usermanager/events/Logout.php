<?php
class core_usermanager_events_Logout extends core_common_MessageBase  {
}
?>