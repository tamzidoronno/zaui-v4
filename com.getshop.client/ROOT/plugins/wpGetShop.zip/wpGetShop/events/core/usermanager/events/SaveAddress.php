<?php
class core_usermanager_events_SaveAddress extends core_common_MessageBase  {
	/** @var core_usermanager_data_Address */
	public $address;

}
?>