<?php
class core_usermanager_events_UserDeleted extends core_common_MessageBase  {
	/** @var core_usermanager_data_User */
	public $user;

}
?>