<?php
class WHAT_IS_THIS {
}
?>