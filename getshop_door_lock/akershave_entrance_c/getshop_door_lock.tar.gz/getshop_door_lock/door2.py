#!/usr/bin/python

import codelock

if __name__ == "__main__":
    lock = codelock.DoorLock(13, 11, 22, 17, 51518)
    lock.main()

