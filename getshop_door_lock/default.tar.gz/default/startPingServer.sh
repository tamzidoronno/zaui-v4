#!/bin/bash

while true; do
    python /root/getshop_door_lock/pingwebserver.py
done 
