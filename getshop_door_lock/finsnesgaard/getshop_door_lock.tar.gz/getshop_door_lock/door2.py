#!/usr/bin/python

import codelock

if __name__ == "__main__":
    # LED, OPENBUTTON, STRIKE_RELAY, DOORENGINE_RELAY, SOCKETPORT
    lock = codelock.DoorLock(16, 11, 22, 17,  51517, 1, True, "https://finsnesgaard.getshop.com/scripts/pushAccessCode.php?engine=default&id=1&code={CODE}&domain=External%20Door")
    lock.main()

