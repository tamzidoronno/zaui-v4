#!/bin/bash
# Comment in the lines below
# and change the address to the correct hotel + username and password

curl -L "https://finsnesgaard.getshop.com/scripts/fetchCodesApac.php?username=entrance@getshop.com&password=asdfijj213i1jj1j1ij1jsn&lockId=963007b3-338e-442d-8aea-f3a21d53eeeb&serverId=09922265-437f-4766-b025-fc2a1121656b" > /storage/validcodes_tmp.txt
foo="`cat /storage/validcodes_tmp.txt`"
echo $foo
if [[ $foo == ,* ]] && [[ $foo == *, ]]
then
	echo $foo > /storage/validcodes.txt
fi
rm -rf /storage/validcodes_tmp.txt
