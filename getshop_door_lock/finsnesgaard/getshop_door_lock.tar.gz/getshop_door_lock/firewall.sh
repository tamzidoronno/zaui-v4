#!/bin/bash
iptables -A INPUT -p tcp -s localhost --dport 51517 -j ACCEPT
iptables -A INPUT -p tcp --dport 51517 -j DROP
iptables -A INPUT -p tcp -s localhost --dport 51518 -j ACCEPT
iptables -A INPUT -p tcp --dport 51518 -j DROP
