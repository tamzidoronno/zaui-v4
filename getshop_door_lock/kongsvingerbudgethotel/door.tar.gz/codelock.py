
#!/usr/bin/python
import socket
import RPi.GPIO as GPIO
import time
import threading
import subprocess

from numpy import recfromcsv


client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect(('localhost', 51717))

GPIO.setmode(GPIO.BCM)
GPIO.setup(23, GPIO.OUT)
GPIO.output(23, True)

GPIO.setup(9, GPIO.OUT)
GPIO.output(9, True)


#Button open lock
GPIO.setup(17, GPIO.IN, pull_up_down=GPIO.PUD_UP)

#Signal from door opener
GPIO.setup(5, GPIO.IN, pull_up_down=GPIO.PUD_UP)

#Door opener
GPIO.setmode(GPIO.BCM)
GPIO.setup(2, GPIO.OUT)
GPIO.setup(16, GPIO.OUT)

#Set opening signals to default True ( this means that the lock should be locked and the door opener should not be activated during start)
GPIO.output(16, True)
GPIO.output(2, True)

concattedPin = "";

def checkOpenLockButton():
    while(1): 

	print GPIO.input(17)

        if (GPIO.input(17) == 0):
            openDoor();

        if (GPIO.input(5) == 0):
            openDoor();

        time.sleep(0.2);

def blinkLeds():
    GPIO.output(23, False)
    time.sleep(5)
    GPIO.output(23, True)
   
def openDoor():
    global concattedPin
    concattedPin = ""
    blinkThread = threading.Thread(target=blinkLeds)
    blinkThread.start()

    #subprocess.call("/root/getshop_door_lock/unlock.sh", shell=True)
    
    unlockDoorThread = threading.Thread(target=unlockDoorStartThread)
    unlockDoorThread.start()

    time.sleep(0.3);
    print "open"
    GPIO.output(16, False)
    time.sleep(0.2)
    GPIO.output(16, True)
    time.sleep(10);


def unlockDoor():
    blinkThread = threading.Thread(target=unlockDoorStartThread)
    blinkThread.start()

def unlockDoorStartThread():
    print "unlocking";
    
    GPIO.output(2, False)
    time.sleep(10)
    GPIO.output(2, True)

def checkPinCode(code):
   print "code: " +  code
   f = open('validcodes.txt', 'r')
   validCodes = f.read()
 
   if len(code) < 6:
        return

   if code in validCodes:
        openDoor();
   

def main():
    global concattedPin
    buttonThread = threading.Thread(target=checkOpenLockButton)
    buttonThread.start();

    while 1:
        data = client_socket.recv(512)
        concattedPin = concattedPin + data
        concattedPin = concattedPin[-6:]
        checkPinCode(concattedPin)

if __name__ == "__main__":
    main()
