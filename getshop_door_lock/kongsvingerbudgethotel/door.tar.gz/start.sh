cd /root/getshop_door_lock;
./socket&
python codelock.py&
python pingwebserver.py&
