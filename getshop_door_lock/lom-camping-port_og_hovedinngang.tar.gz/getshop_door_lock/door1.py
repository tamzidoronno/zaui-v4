
import codelock

if __name__ == "__main__":
    # LED, OPENBUTTON, STRIKE_RELAY, DOORENGINE_RELAY, SOCKETPORT
    #lock = codelock.DoorLock(16, 7, 10, 27, 51517)
    lock = codelock.DoorLock(13, 7, 10, 17, 51518, 1, True, "https://lomcamping.getshop.com/scripts/apac/registerActivityEntrance.php?serverId=7523acaa-b732-4e8e-a5e1-ca734ef8083b&lockId=f7fab988-6e28-4dcc-a8c8-740144eccbb4&code={CODE}")
    lock.main()

