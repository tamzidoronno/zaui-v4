#!/usr/bin/python

import codelock

if __name__ == "__main__":
#    lock = codelock.DoorLock(16, 7, 10, 27, 51517)
    # LED, OPENBUTTON, STRIKE_RELAY, DOORENGINE_RELAY, SOCKETPORT
    lock = codelock.DoorLock(16, 11, 27, 1, 51517, 1, True, "https://lomcamping.getshop.com/scripts/apac/registerActivityEntrance.php?serverId=7523acaa-b732-4e8e-a5e1-ca734ef8083b&lockId=dc424d55-96db-43be-ad8d-8be40e741cdf&code={CODE}")
    lock.main()

