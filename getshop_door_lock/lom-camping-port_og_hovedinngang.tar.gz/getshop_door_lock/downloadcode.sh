#!/bin/bash
curl -L "https://lomcamping.getshop.com/scripts/fetchCodesApac.php?username=entrance@getshop.com&password=2934joasidjoaijr2iaso&lockId=f7fab988-6e28-4dcc-a8c8-740144eccbb4&serverId=7523acaa-b732-4e8e-a5e1-ca734ef8083b" > /storage/validcodes_tmp.txt
foo="`cat /storage/validcodes_tmp.txt`"
echo $foo
if [[ $foo == ,* ]] && [[ $foo == *, ]]
then
	echo $foo > /storage/validcodes.txt
fi
rm -rf /storage/validcodes_tmp.txt
