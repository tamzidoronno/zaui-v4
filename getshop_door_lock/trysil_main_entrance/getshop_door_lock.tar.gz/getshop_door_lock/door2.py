#!/usr/bin/python

import codelock

if __name__ == "__main__":
#    lock = codelock.DoorLock(16, 7, 10, 27, 51517)
    lock = codelock.DoorLock(16, 7, 22, 17, 51517, 2, True, "")

    lock.main()

