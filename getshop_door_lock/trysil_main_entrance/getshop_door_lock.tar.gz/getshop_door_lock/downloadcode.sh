#!/bin/bash
curl -L "https://trysilhotell.getshop.com/scripts/fetchCodesApac.php?engine=default&username=entrancedoor@getshop.com&password=g44gfd22&serverId=403c5769-4148-4c1d-86d9-2bf78f4ae3e1&lockId=dd6c7a04-81d1-4325-8342-f74d107f8793"  > /storage/validcodes_tmp.txt
foo="`cat /storage/validcodes_tmp.txt`"
echo $foo
if [[ $foo == ,* ]] && [[ $foo == *, ]]
then
	echo $foo > /storage/validcodes.txt
fi
rm -rf /storage/validcodes_tmp.txt
