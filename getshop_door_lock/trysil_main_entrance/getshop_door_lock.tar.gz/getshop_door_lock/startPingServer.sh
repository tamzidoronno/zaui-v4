#!/bin/bash
while :
do
    python pingwebserver.py
done
