#!/bin/bash
# Comment in the lines below
# and change the address to the correct hotel + username and password

curl -L "https://utsiktenhotell.getshop.com/scripts/fetchCodes.php?engine=default&username=entrancedoor@getshop.com&password=vvueeh0k911"  > /storage/validcodes_tmp.txt
foo="`cat /storage/validcodes_tmp.txt`"
echo $foo
extracode="783625,"
if [[ $foo == ,* ]] && [[ $foo == *, ]]
then
	echo $foo$extracode > /storage/validcodes.txt
	#echo "783625," >> /storage/validcodes.txt
fi
rm -rf /storage/validcodes_tmp.txt
