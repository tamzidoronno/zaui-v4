# HTTP Push Z-Way HA module

Pushes status of an object to a specified URL.